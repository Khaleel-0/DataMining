% Author : Noura Alroomi

clear;
clc;
close all;
% read dataset
% JawClench_tabel = readmatrix("Data_JawClench_features.csv");
JawClench_tabel = readmatrix("balanced_Data_JawClench_features.csv");



% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];
% denfine features without Mean
% featuresNames = ["Peak Value", "Standard Dev", "SNR"];

featuresNames_channel = []; 

% denfine channels features col names
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       featuresNames_channel=[featuresNames_channel channels{channel}+"_"+featuresNames{feature}] ;
    end
end 
% add label to channels features col names
featuresNames_channel=[featuresNames_channel "Label"];


%  denfine col names for Post-PCA data
PCfeaturesNames_channel = ["PC1","PC2","PC3","PC4","PC5","PC6","PC7",...
   "PC8","PC9","PC10","PC11","PC12","PC13","PC14",...
   "PC15","PC16","PC17","PC18","PC19","PC20","PC21",...
   "PC22","PC23","PC24","PC25","PC26","PC27","PC28","Label"];

%  denfine col names for Post-PCA data without Mean
% PCfeaturesNames_channel = ["PC1","PC2","PC3","PC4","PC5","PC6","PC7",...
%    "PC8","PC9","PC10","PC11","PC12","PC13","PC14",...
%    "PC15","PC16","PC17","PC18","PC19","PC20","PC21","Label"];

% get Mean  features col IDs
% mean_ind = [];
% for i =1:width(JawClench_tabel)-1
%     if mod(i,4) == 1
%         mean_ind = [ mean_ind i ];
%     end
% end

% remove Mean features
% JawClench_tabel(:,mean_ind) = [];

 % fetch data dimentions
[observations, features] = size(JawClench_tabel); 




% perform PCA SVD to get U
[U, S ,V] = svd(JawClench_tabel(:,1:(features-1)),0); 
% calculate Ur 
Ur = U*S;

% create filters for the classes
nonJawClench = JawClench_tabel(:,features) == 0;
JawClench = JawClench_tabel(:,features) == 1; 
% 
% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

tables = {nonClench_tabel,Clench_tabel};


% add label to U
U(:,features) = JawClench_tabel(:,features);

% fetch classes data based on filters
U_nonClench_tabel = U(nonJawClench,:);
U_Clench_tabel = U(JawClench,:);

U_tables = {U_nonClench_tabel,U_Clench_tabel};

% add label to Ur
Ur(:,features) = JawClench_tabel(:,features);

% fetch classes data based on filters
Ur_nonClench_tabel = Ur(nonJawClench,:);
Ur_Clench_tabel = Ur(JawClench,:);

Ur_tables = {Ur_nonClench_tabel,Ur_Clench_tabel};



% split origial data to train test sets
[train_set, test_set] = split_data(tables);

% Set columns names for training data
train_table = array2table(train_set,'VariableNames',featuresNames_channel);
% save training data to file
writetable(train_table,"Train_balanced_Data_JawClench_features.csv");
% Set columns names for testing data
test_table = array2table(test_set,'VariableNames',featuresNames_channel);
% save testing data to file
writetable(test_table,"Test_balanced_Data_JawClench_features.csv");

% split U data to train test sets
[U_train_set, U_test_set] = split_data(U_tables);
% Set columns names for training data
U_train_table = array2table(U_train_set,'VariableNames',PCfeaturesNames_channel);
% save training data to file
writetable(U_train_table,"no_mean_U_Train_balanced_Data_JawClench_features.csv");
% Set columns names for testing data
U_test_table = array2table(U_test_set,'VariableNames',PCfeaturesNames_channel);
% save testing data to file
writetable(U_test_table,"no_mean_U_Test_balanced_Data_JawClench_features.csv");

% split Ur data to train test sets
[Ur_train_set, Ur_test_set] = split_data(Ur_tables);
% Set columns names for training data
Ur_train_table = array2table(Ur_train_set,'VariableNames',PCfeaturesNames_channel);
% save training data to file
writetable(Ur_train_table,"no_mean_Ur_Train_balanced_Data_JawClench_features.csv");
% Set columns names for testing data
Ur_test_table = array2table(Ur_test_set,'VariableNames',PCfeaturesNames_channel);
% save testing data to file
writetable(Ur_test_table,"no_mean_Ur_Test_balanced_Data_JawClench_features.csv");



 




% function to split the data set of each classes country to train_set and test_set
function [train_set, test_set] =  split_data(classes_tables)
    
    % create matrix  to collect test set
    test_set = [];
    % create matrix  to collect train set
    train_set= [];
    % loop over classes data to collect 1/3 of it randomlly for testing and the rest for training 
    for class = 1:length(classes_tables)
        % fetch class dataset
        
        table = cell2mat(classes_tables(class));
        % fetch dataset size 
        [observations, features] = size(table); 
        
        % class dataset test set size
        test_size = ceil(observations*0.3) ;
        
        % loop over class observations 
        for j=1:observations 
            % random assigned number for each observations to new column
            table(j,features+1)=rand; 
        end

        % sort based on the random assigned number column
        rand_table=sortrows(table,features+1);
        % fetch the first observations based on test_size of the class for testset 
        class_test_set =[rand_table(1:test_size,1:features)]; 
        % fetch the rest of the observations based on test_size of the class for trainset 
        class_train_set =[rand_table(test_size+1:observations,1:features)];
        % append class_test_set to test_set
        test_set = [test_set;class_test_set];
        % append class_train_set to train_set
        train_set = [train_set;class_train_set];
    end 

end
