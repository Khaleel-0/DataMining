clear;
clc;
close all;
% read dataset
JawClench_tabel = readtable("Data_JawClench_features.csv");

%Author: Noura Alroomi

% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];
cols = []; 

% create the feature names 
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+" "+featuresNames{feature}] ;
    end
end


% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% set classes tables list
tables = {nonClench_tabel; Clench_tabel};
classes  = {"nonJawClench","JawClench"};






% normlized and mean center that datasets
for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
    %      mean_value = mean(data);
    %      std_value = std(data);
    %      data = (data-mean_value)/std_value;
     
     JawClench_tabel{:,col} = data;
end



%loop over the dataset features to calculate basic stat
for col = 1:width(JawClench_tabel)-1
    values = {};
    % calculate feature's mean,and std
    mean_value = mean(JawClench_tabel{:,col});
    std_value = std(JawClench_tabel{:,col});
    % add the feature's basic stat values to a array
    values{1} = mean_value;
    values{2} = std_value;
    % disply the feature's basic stat values 
    disp(" - "+cols(col)+": Mean:"+mean_value+", STD:"+std_value+", Mean/STD: "+ (mean_value/std_value) +", STD/Mean: "+(std_value/mean_value));

end
