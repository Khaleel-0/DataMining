%load the train dataset
train = readtable("Ur_Train_balanced_Data_JawClench_features.csv");
%load the test dataset - trial_1, trial_2, trail_3
test = readtable("Ur_Test_balanced_Data_JawClench_features.csv");

[rows, columns] = size(test);

% normalize the features values (divide by the max)
for i=1:columns-1
    train.(i) = train{:,i}./max(train.(i));
end

% normalize the features values (divide by the max)
for i=1:columns-1
    test.(i) = test{:,i}./max(test.(i));
end

% fetch each country dataset alone
clenched_covid_table = train(eq(train.Label,1),:);
non_clenched_covid_table = train(eq(train.Label,0),:);

% Drop population column
clenched_covid_table = clenched_covid_table(:,1:columns-1);
non_clenched_covid_table = non_clenched_covid_table(:,1:columns-1);

% calculate the classes' covariance matrices 
cov_clench = cov(table2array(clenched_covid_table));
cov_non_clench = cov(table2array(non_clenched_covid_table));

% calculate average of the classes' covariance matrices ==> case II
avrg_cov = (cov_clench + cov_non_clench)/2;

% store test data to access the Population column 
original_test = test(:,:);

% convert test1 dataset to of the classes' covariance matrices ==> case II
test = test(:,1:columns-1);

actualLabels = table2array(original_test(:,columns));
disp("labelColumn "+labelColumn);
predictedLabels = [];
% set list of classes
classes = ["Clenched", "NonClenched"]; 
count = 0;

for i = 1:rows
    % apply the g function of all the classes to test dataset and convert it
    % back to probability by e funtion to ln values
    g_array = [exp(g(test{i,:}, 0,train, avrg_cov)) exp(g(test{i,:}, 1,train, avrg_cov))];
    % select the optimal value closest to 0
    [res, maxIndex] = max(g_array);
    % Collect the predicted class to plot the confusion matrix
    predictedLabels(end+1) = maxIndex-1;
    % check if the Population (location name) matches the predicted result
    if eq(original_test{i,columns},maxIndex-1)
        % if prediction is correct increment the count and count the number of correct predictions
        count = count+1;
    end
end

% Compute the confusion matrix  
confusion_matrix = confusionmat(actualLabels,predictedLabels);

% Plot the Confusion matrix
cc = confusionchart(confusion_matrix);
cc.Title = "Original Data";

% Displaying results for test dataset  
disp("Trial 1");
% Display the number of correct predictions  
disp("Correct predictions " + count);
% Display the accuracy using the formula => correct_observations * 100 / total_observations  
disp("Accuracy "+ count*100/rows);
% Display the total observations  
disp("Total Observations "+rows);

% the discriminant function
function post_class =  g(feature_vector, class,covid_table,avrg_cov)
   % fetch each class dataset  
   table_class = covid_table(eq(covid_table.Label,class),:);
   % keep only features of interest 
   [row, column] = size(covid_table);
   % keep only features of interest  
   array = table2array(table_class(:,1:column-1));
   % calculate the features means
   mean_vector_class = mean(array); 
   % use the average covariance ==> sigma
   cov_mat_class = avrg_cov;
   % the difference between the feature vector and the mean vector ==> (feature_vector-mean_vector_class)
   first_term = (feature_vector- mean_vector_class); 
   % transpose he differnce between the feature vector and the mean vector ==> (feature_vector-mean_vector_class)t
   first_term_transpose =  first_term.'; 
   % inverse the covariance matrix ==> sigma^-1
   cov_inverse =  inv(cov_mat_class); 
   % multiply the transposed features and means differnce by the inversed
   % covariance matrix ==> (feature_vector-mean_vector_class)t * sigma^-1 == > (a)
   a = mtimes(cov_inverse,first_term_transpose) ;
   %  multiply the features and means differnce with a 
   % ==> (feature_vector-mean_vector_class)t * sigma^-1 * (feature_vector-mean_vector_class) ==> (b)      
   b = mtimes(first_term,a) ;
   %  multiply -1/2 with b ==> (feature_vector-mean_vector_class)t * sigma^-1 *
   %  (feature_vector-mean_vector_class) * -1/2 ==> (c)
   c = -0.5 * b;
   % calculate ln(P(class)) 
   p_class =  log(height(table_class)/height(covid_table));
   % sum ln(P(class)) with c 
   % (feature_vector-mean_vector_class)t * sigma^-1 * (feature_vector-mean_vector_class) * -1/2 + ln(P(class))
   post_class =  c+p_class; 
end 























