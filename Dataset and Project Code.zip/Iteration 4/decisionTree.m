clc
clear
close all

%Author: Prarin Behdarvandian

%Read in all of the CVS files
regularDataTrain = readtable('Train_balanced_Data_JawClench_features.csv');
regularDataTest = readtable('Test_balanced_Data_JawClench_features.csv');

urDataTrain = readtable('Ur_Train_balanced_Data_JawClench_features.csv');
urDataTest = readtable('Ur_Test_balanced_Data_JawClench_features.csv');

uDataTrain = readtable('U_Train_balanced_Data_JawClench_features.csv');
uDataTest = readtable('U_Test_balanced_Data_JawClench_features.csv');

%Call the decision Tree Function to out results
%Call one at a time

decisionTreeMaker(regularDataTest,regularDataTrain,1)
%decisionTreeMaker(urDataTest,urDataTrain,2)
%decisionTreeMaker(uDataTest,uDataTrain,3)

function decisionTreeMaker(test_Data,train_Data, type)
lenColumns = width(train_Data);

    dataTypeList = ["Pre-PCA Decision Tree Data without Mean","UR Decision Tree Data without Mean", "U Decision Tree Data without Mean"];
    typeTitle = dataTypeList(type);
    lenColumns = width(train_Data);
    
    %Split the data to training data and Label
    features_train = train_Data(:,1:lenColumns-1);
    label_train = train_Data(:,lenColumns);
    
    %Split the data to testing data and Label
    features_test =  test_Data(:,1:lenColumns-1);
    label_test = test_Data(:,lenColumns);
    
    %Create the model
    model_Decision_Tree = fitctree(features_train,label_train);
    %Create the prediction labels based on the model
    label_predict = predict(model_Decision_Tree,features_test);
    %Create a viewable decision tree
    view(model_Decision_Tree,'Mode','graph')
    title(typeTitle)

    
    %Accuracy
    label_test = table2array(label_test);
    %Create an array confusion matrix
    compare_Results = confusionmat(label_test,label_predict);
    %Output the results of the confusion matrix in chart
    chart = confusionchart(label_test,label_predict);
    chart.RowSummary = 'row-normalized';
    chart.ColumnSummary = 'column-normalized';
    title(typeTitle)
    
    %Retrieve the overall accuracy
    total_Correct = compare_Results(1,1)+ compare_Results(2,2);
    total_Overall = compare_Results(1,1) + compare_Results(2,2) + compare_Results(1,2)+ compare_Results(2,1);
    
    %Display the percentage of accuracy
    accuracy_Percentage = (total_Correct/total_Overall)*100;
    disp(accuracy_Percentage);


end


