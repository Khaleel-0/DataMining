clear;
clc;
close all;

%Author: Pragati Dode


% Loading dataset
JawClench_tabel1 =readtable("Data_JawClench_features.csv");

%Skip all columns of Singnal to Noise Ratio
JawClench_tabel2 = JawClench_tabel1(:,[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19,21,22,23,25,26,27,29]);

%Seprate Jaw clench and Non jaw clench data 
nonJawClench = JawClench_tabel2.Label == 0;
JawClench = JawClench_tabel2.Label == 1; 
nonJawClench_tabel = JawClench_tabel2(nonJawClench,:);
JawClench_tabel = JawClench_tabel2(JawClench,:);

%select ranndomely 363 rows from non jaw celnch to balance dataset  
%363 random integers from the set 1-885 (no replacement)
k = randperm(885,363);
% select the random rows
random_nonJawClench_tabel = nonJawClench_tabel(k,:);   
balanced_table = [random_nonJawClench_tabel; JawClench_tabel] ;

% Conevrts JawClench_tabel1 to JawClenchMatrix
JawClenchMatrix = table2array(balanced_table);

% fetch classes indices from JawClenchMatrix
rows_JawClench = JawClenchMatrix (:,22)==1;
rows_NonJawClench =  JawClenchMatrix (:,22)==0;


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %  
% 
% % Basic PCA process script 
% 
% % this just transforms and plots data, it is up to you 
% 
% % to provide the appropriate interpretation, which is the 
% 
% % most valuable part of PCA 
% 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %  



[nrows, ncols] = size(JawClenchMatrix); 

Jaw_data = zeros([nrows,ncols]); 

ss_i = zeros([1,ncols]);   % use this for the scree plot 

ss_cu = zeros([1,ncols]);  % use this for the cumulative scree plot 

means = mean(JawClenchMatrix(:,1:21));    

vars = var(JawClenchMatrix(:,1:21)); 

stdevs = std(JawClenchMatrix(:,1:21)); 

% % Scale data 
% 
% % This is necessary so that all data has the same order, e.g.,  
% 
% % should not compare values in the thousands vs. values between 0 and 1 



for i=1:ncols 

    col_max = max(JawClenchMatrix(:,i));
    col_min = min(JawClenchMatrix(:,i));

    for j=1:nrows


        Jaw_data(j,i) = (JawClenchMatrix(j,i) - col_min )/(col_max-col_min);


    end 

end 


% % Mean center data 
% % 
% % This is necessary so that everything is mean centered at 0 
% % 
% % facilitates statistical and hypothesis analysis 


for i=1:ncols 

    for j=1:nrows
        if i == 22
            Jaw_data(j,i) = JawClenchMatrix(j,i); 
        else

        Jaw_data(j,i) = (JawClenchMatrix(j,i) -  means(:,i))/stdevs(:,i);
        end 

    end 

end 

abs(mean(Jaw_data)) 
var(Jaw_data) 


Jaw_data_table = array2table(Jaw_data);
Jaw_data_Clench = Jaw_data_table.Jaw_data22 == 1;
Jaw_data_NonClench = Jaw_data_table.Jaw_data22 == 0;

Jaw_data_Clench_tabel = Jaw_data_table(Jaw_data_Clench,:);
Jaw_data_NonClench_tabel = Jaw_data_table(Jaw_data_NonClench,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Pre-PCA Test of classifier   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data selection
d1 = Jaw_data_Clench_tabel;
d2 = Jaw_data_NonClench_tabel;
% Spliting data in testing and training
P = 0.30 ;
cv1 = cvpartition(size(d1,1),'HoldOut',P);
data_train_Clench = d1(cv1.training,:);
data_test_Clench = d1(cv1.test,:);

cv2 = cvpartition(size(d2,1),'HoldOut',P);
data_train_NonClench = d2(cv2.training,:);
data_test_NonClench = d2(cv2.test,:);
%Combining both Clench and non Clench data
data_test_both_class = [data_test_Clench;data_test_NonClench];
data_train_both_class =[data_train_Clench;data_train_NonClench];

%Seprating traing and testing data for classifier 
x_train = data_train_both_class(:,1:21);
y_train = data_train_both_class(:,22);
x_test = data_test_both_class(:,1:21);
y_test = data_test_both_class(:,22);
y_test_array=table2array(y_test);

% Decision Tree Model 
Mdl = fitctree(x_train,y_train);
y_predict = predict(Mdl,x_test);
view(Mdl,'Mode','graph')
%  Check accuracy of model
result = confusionmat(y_test_array,y_predict);
chart = confusionchart(y_test_array,y_predict);
chart.NormalizedValues
chart.Title = "Confusion Chart Pre-PCA";
chart.RowSummary = 'row-normalized';
chart.ColumnSummary = 'column-normalized';
accuracy = (result(1,1)+result(2,2))*100/(result(1,1)+result(1,2)+result(2,1)+result(2,2));

% % Jaw_data is the original dataset 
% % 
% % Ur will be the transformed dataset  
% % 
% % S is covariance matrix (not normalized) 

[U, S ,V] = svd(Jaw_data(:,1:ncols-1),0); 

Ur = U*S;                

% Number of features to use 

f_to_use = ncols-1;      
feature_vector = 2:f_to_use; 
r = Ur;  % make a copy of Ur to preserve it 


% Obtain the necessary information for Scree Plots 
% 
% Obtain S^2 (and can also use to normalize S)   
S2 = S^2; 

weights2 = zeros(ncols-1,1); 

sumS2 = sum(sum(S2)); 

weightsum2 = 0; 

 for i=1:(ncols-1) 

    weights2(i) = S2(i,i)/sumS2; 

    weightsum2 = weightsum2 + weights2(i); 

    weight_c2(i) = weightsum2; 

end 
figure; 
hold on

plot(weights2,'x:b'); 
plot(weight_c2,'x:r'); 

grid; 

title('Scree Plot and Scree Plot Cumulative'); 
legend({"Scree Plot","Scree Plot Cumulative"})

hold off
nfeatures = ncols-1;

for i=1:nfeatures

    for j=1:nfeatures 

        Vsquare(i,j) = V(i,j)^2; 

        if V(i,j)<0 

            Vsquare(i,j) = Vsquare(i,j)*-1; 

        else  

            Vsquare(i,j) = Vsquare(i,j)*1; 

        end 

    end 

end 
%Plot Loading Vectors
for v = 1:width(Vsquare)


    figure; 
    
    bar(Vsquare(:,v),0.5); 
    
    grid; 
    
    ymin = min(Vsquare(:,v)) + (min(Vsquare(:,v))/10); 
    
    ymax = max(Vsquare(:,v)) + (max(Vsquare(:,v))/10); 
    
    axis([0 nfeatures ymin ymax]); 
    
    xlabel('Feature index'); 
    
    ylabel('Importance of feature'); 
    
    [chart_title, ERRMSG] = sprintf('Loading Vector %d',v); 
    
    title(chart_title);

end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %  Post-PCA Test of classifier for U  %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get the labels from the original data
NewCol = Jaw_data(:,22);
% Add new column
U = [U NewCol];

%Seperate the U data into clench and non clench
U_Jaw_Clench_rows = U(:,22)==1;
U_Non_Clench_rows = U(:,22)==0; 
U_Jaw_Clench= U(U_Jaw_Clench_rows,:);
U_Non_Clench = U(U_Non_Clench_rows,:);
% Data selection
d1 = U_Jaw_Clench;
d2 = U_Non_Clench;
% Spliting data in testing and training
P = 0.30 ;
cv1 = cvpartition(size(d1,1),'HoldOut',P);
data_train_Clench = d1(cv1.training,:);
data_test_Clench = d1(cv1.test,:);

cv2 = cvpartition(size(d2,1),'HoldOut',P);
data_train_NonClench = d2(cv2.training,:);
data_test_NonClench = d2(cv2.test,:);
%Combining both Clench and non Clench data
data_test_both_class = [data_test_Clench;data_test_NonClench];
data_train_both_class =[data_train_Clench;data_train_NonClench];

%Seprating traing and testing data for classifier 
x_train = data_train_both_class(:,1:21);
y_train = data_train_both_class(:,22);
x_test = data_test_both_class(:,1:21);
y_test = data_test_both_class(:,22);

% Decision Tree Model 
Mdl = fitctree(x_train,y_train);
y_predict = predict(Mdl,x_test);
view(Mdl,'Mode','graph')
%  Check accuracy of model
result = confusionmat(y_test,y_predict);
chart = confusionchart(y_test,y_predict);

chart.NormalizedValues
chart.Title = "Confusion Chart for U";
chart.RowSummary = 'row-normalized';
chart.ColumnSummary = 'column-normalized';
accuracy = (result(1,1)+result(2,2))*100/(result(1,1)+result(1,2)+result(2,1)+result(2,2));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Post-PCA Test of classifier for Ur  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Get the labels from the original data
NewCol = Jaw_data(:,22);
%Add new column
Ur = [Ur NewCol];
% Data selection
d = Ur;
% Spliting data in testing and training

P = 0.30 ;
cv = cvpartition(size(d,1),'HoldOut',P);
data_train = d(cv.training,:);
data_test = d(cv.test,:);
x_train = data_train(:,1:21);
y_train = data_train(:,22);
x_test = data_test(:,1:21);
y_test = data_test(:,22);

% Get the labels from the original data
NewCol = Jaw_data(:,22);
% Add new column
Ur = [Ur NewCol];

%Seperate the U data into clench and non clench
Ur_Jaw_Clench_rows = Ur(:,22)==1;
Ur_Non_Clench_rows = Ur(:,22)==0; 
Ur_Jaw_Clench= Ur(Ur_Jaw_Clench_rows,:);
Ur_Non_Clench = Ur(Ur_Non_Clench_rows,:);
% Data selection
d1 = Ur_Jaw_Clench;
d2 = Ur_Non_Clench;
% Spliting data in testing and training
P = 0.30 ;
cv1 = cvpartition(size(d1,1),'HoldOut',P);
data_train_Clench = d1(cv1.training,:);
data_test_Clench = d1(cv1.test,:);

cv2 = cvpartition(size(d2,1),'HoldOut',P);
data_train_NonClench = d2(cv2.training,:);
data_test_NonClench = d2(cv2.test,:);
%Combining both Clench and non Clench data
data_test_both_class = [data_test_Clench;data_test_NonClench];
data_train_both_class =[data_train_Clench;data_train_NonClench];

%Seprating traing and testing data for classifier 
x_train = data_train_both_class(:,1:21);
y_train = data_train_both_class(:,22);
x_test = data_test_both_class(:,1:21);
y_test = data_test_both_class(:,22);

% Decision Tree Model 
Mdl = fitctree(x_train,y_train);
y_predict = predict(Mdl,x_test);
view(Mdl,'Mode','graph')
%  Check accuracy of model
result = confusionmat(y_test,y_predict);
chart = confusionchart(y_test,y_predict);

chart.NormalizedValues
chart.Title = "Confusion Chart for Ur";
chart.RowSummary = 'row-normalized';
chart.ColumnSummary = 'column-normalized';
accuracy = (result(1,1)+result(2,2))*100/(result(1,1)+result(1,2)+result(2,1)+result(2,2));