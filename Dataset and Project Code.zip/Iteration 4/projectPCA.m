clear;
clc;
close all;

%Author: Melody Behdarvadian

fullData = readmatrix('balanced_Data_JawClench_features.csv'); 

[nrows, ncols] = size(fullData); 

X = zeros([nrows,ncols]); 

%Mean, Variance, Standard Deviation of
means = mean(fullData);    
vars = var(fullData); 
stdevs = std(fullData); 

%Scaling the Data
for i=1:(ncols-1) 
    col_max = max(fullData(:,i));
    col_min = min(fullData(:,i));
    for j=1:nrows
        if i == 1
            X(j,i) = fullData(j,i); 
        else
        X(j,i) = (fullData(j,i) - col_min )/(col_max-col_min);
        end 
    end 
end 

%Mean center data
for i=1:(ncols-1)
    for j=1:nrows
        if i == 1
            X(j,i) = fullData(j,i); 
        else

        X(j,i) = (fullData(j,i) -  means(:,i))/stdevs(:,i);
        end 

    end 

end 

X(:,ncols) = fullData(:,ncols);


abs(mean(X))
var(X)


[U, S ,V] = svd(X(:,(1:(ncols-1))),0); 

Ur = U*S;

f_to_use = ncols-1;      

feature_vector = 1:f_to_use;

r = Ur;  % make a copy of Ur to preserve it,  we will randomize r

% Obtain the necessary information for Scree Plots 

% Obtain S^2 (and can also use to normalize S)   

% 

S2 = S^2; 

weights2 = zeros(ncols-1,1); 

sumS2 = sum(sum(S2)); 

weightsum2 = 0; 

 

for i=1:(ncols-1) 

    weights2(i) = S2(i,i)/sumS2; 

    weightsum2 = weightsum2 + weights2(i); 

    weight_c2(i) = weightsum2; 

end 


figure; 


hold on

plot(weights2,'x:b'); 
plot(weight_c2,'x:r'); 

percent = weights2*100;

grid; 

title('Scree Plot and Scree Plot Cumulative'); 
legend({"Scree Plot","Scree Plot Cumulative"})


nfeatures = ncols-1;

for i=1:nfeatures

    for j=1:nfeatures 

        Vsquare(i,j) = V(i,j)^2; 

        if V(i,j)<0 

            Vsquare(i,j) = Vsquare(i,j)*-1; 

        else  

            Vsquare(i,j) = Vsquare(i,j)*1; 

        end 

    end 

end 



for v = 1:width(Vsquare)


    fig = figure(); 

    bar(Vsquare(:,v),0.5,"blue"); 
    
    grid; 
    
    ymin = min(Vsquare(:,v)) + (min(Vsquare(:,v))/10); 
    
    ymax = max(Vsquare(:,v)) + (max(Vsquare(:,v))/10); 
    
    axis([0 nfeatures ymin ymax]); 
    
    xlabel('Feature index'); 
    
    ylabel('Importance of feature'); 
    
    [chart_title, ERRMSG] = sprintf('Loading Vector %d',v); 
    
    title(chart_title);
    %saveas(fig,"LV_"+v+".png")

end


Ur(:,ncols) = fullData(:,ncols);

UrRest = Ur(Ur(:,ncols)==0,:);
UrClench = Ur(Ur(:,ncols)==1,:);

nPCA = 4;

for x=1:nPCA
    for y=x+1:nPCA
        for z=y+1:nPCA
            fig = figure(); 
            scatter3(UrClench(:,x), UrClench(:,y), UrClench(:,z), 'red');
            hold on;
            scatter3(UrRest(:,x), UrRest(:,y), UrRest(:,z), 'blue');

            str = "Ur 3D Plots for PCAs";

           

            [xLabel, ERRMSG] = sprintf('PCA %d',x);
            [yLabel, ERRMSG] = sprintf('PCA %d',y);
            [zLabel, ERRMSG] = sprintf('PCA %d',z);

            xlabel(xLabel); 
            ylabel(yLabel);
            zlabel(zLabel);
            legend('Clench','Non-Clench')
            title(str);
            saveas(fig,"PCA Plot for_"+x+ "_"+y+"_"+z+".png");
        end
    end
end

U(:,ncols) = fullData(:,ncols);

URest = U(U(:,ncols)==0,:);
UClench = U(U(:,ncols)==1,:);

nPCA = 4;

for x=1:nPCA
    for y=x+1:nPCA
        for z=y+1:nPCA
            fig = figure(); 
            scatter3(UClench(:,x), UClench(:,y), UClench(:,z), 'red');
            hold on;
            scatter3(URest(:,x), URest(:,y), URest(:,z), 'blue');

            str = "U 3D Plots for PCAs";

            [xLabel, ERRMSG] = sprintf('PCA %d',x);
            [yLabel, ERRMSG] = sprintf('PCA %d',y);
            [zLabel, ERRMSG] = sprintf('PCA %d',z);

            xlabel(xLabel); 
            ylabel(yLabel);
            zlabel(zLabel);
            legend('Clench','Non-Clench')
            title(str);
            saveas(fig,"U PCA Plot for_"+x+ "_"+y+"_"+z+".png");
        end
    end
end


