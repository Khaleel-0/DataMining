clear;
clc;
close all;
% read dataset
JawClench_tabel = readtable("Data_JawClench_features.csv");

%Author: Noura Alroomi

% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];
 cols = []; 

% create the feature names 
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+" "+featuresNames{feature}] ;
    end
end


% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% set classes tables list
tables = {nonClench_tabel; Clench_tabel};
classes  = {"nonJawClench","JawClench"};






% normlized and mean center that datasets
for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
%      mean_value = mean(data);
%      std_value = std(data);
%      data = (data-mean_value)/std_value;
     

     JawClench_tabel{:,col} = data;
end

% fetch channels features indicies
cols_indcies = [];
for col =1 :width(JawClench_tabel)-1
    if mod(col,4) == 1
        cols_indcies = [cols_indcies col];
    end     
end
    

% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% create plots combinations 
scatter_plots_3d = nchoosek(1:4,3);

% Loop over channnels to create 3d plots  
for ch =1:length(channels)
    % fetch channel features indicies
    offset_col = cols_indcies(ch);
    % fetch classes channel features    
    channel_nonClench_tabel = table2array(JawClench_tabel(nonJawClench,offset_col:offset_col+3));
    channel_Clench_tabel = table2array(JawClench_tabel(JawClench,offset_col:offset_col+3));
    % plot 3D Scatter plot based combinations 
    for comb= 1:height(scatter_plots_3d)
        % fetch features combinations
        sp = scatter_plots_3d(comb,:);
        
        fig = figure();
        % plot nonClench  data
        scatter3(channel_nonClench_tabel(:,sp(1)),channel_nonClench_tabel(:,sp(2)),channel_nonClench_tabel(:,sp(3)),"blue")
        hold on
        % plot clench  data
        scatter3(channel_Clench_tabel(:,sp(1)),channel_Clench_tabel(:,sp(2)),channel_Clench_tabel(:,sp(3)),"red")
        % add title
        title(channels(ch)+ " Channel "+ featuresNames(sp(1))+", "+featuresNames(sp(2)) +" and "+featuresNames(sp(3)) +" Features Scatter Plot")
        % add x y z access label
        xlabel(featuresNames(sp(1)))
        ylabel(featuresNames(sp(2)))
        zlabel(featuresNames(sp(3)))
        % add legend
        legend(classes);

        hold off 
        % save fig
%         saveas(fig,"channel_features_3d/"+channels(ch)+ " Channel "+ featuresNames(sp(1))+", "+featuresNames(sp(2)) +", and "+featuresNames(sp(3)) +" Features Scatter Plot.png");
    end
    close all;

end
