function graph = graph_gabor(raw_data, window_size, overlap, displayFFT)
%GRAPH_GABOR Summary of this function goes here
%   Detailed explanation goes here

assert(overlap < window_size, ...
    'You cannot overlap more than the size than the window! Perhaps swap your window_size/overlap variables?')


for index = 1:length(raw_data) 
    matrix = raw_data{index};

    % displayFFT is more for testing so we resize matrix for easier
    % visualization, so we can just look at the first column
    if displayFFT
        matrix = matrix(:,1);
    end

    output = gabor_transform(matrix, window_size, overlap, displayFFT);

    dp = find(output, 1);

    % output(1:dp,:) = 0;

    graph = zeros(size([matrix, output]));

    for jindex = 1:width(matrix)
        gindex = jindex - 1;
        gindex = gindex * 2;
        gindex = gindex + 1;

        %graph(:,gindex) = EEGFILTFFT(graph(:,gindex), 300, 1, 50); % bandpass(graph(:,gindex), [1, 50], 300);
        
        graph(:,gindex) = matrix(:,jindex);

        graph(:,gindex + 1) = output(:,jindex);
    end

    figIndex = index;

    % There will be many other graphs but we want to also see the bigger
    % picture so we put the final graph at a really big number so it
    % doesn't overwrite anything
    if displayFFT
        figIndex = figIndex + 10000;
    end

    figure(figIndex);
    t = stackedplot(graph);
    t.Title = sprintf('Figure %d unfiltered data', index);
    t.XLabel = 'Data Points (300 samples per second)';

    if displayFFT
        t.DisplayLabels = ["Microvolts", "Algorithm Output"];
    else
        t.DisplayLabels = ["LE (Microvolts)", "LE Algorithm Output", ... 
                           "F4 (Microvolts)", "F4 Algorithm Output", ...
                           "C4 (Microvolts)", "C4 Algorithm Output", ...
                           "P4 (Microvolts)", "P4 Algorithm Output", ...
                           "P3 (Microvolts)", "P3 Algorithm Output", ...
                           "C3 (Microvolts)", "C3 Algorithm Output", ...
                           "F3 (Microvolts)", "F3 Algorithm Output"];
    end
    
end


end

