% Author : Noura Alroomi

clear;
clc;
close all;

% read dataset
JawClench_tabel = readmatrix("Data_JawClench_features.csv");



% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];

featuresNames_channel = []; 

% denfine channels features col names
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       featuresNames_channel=[featuresNames_channel channels{channel}+"_"+featuresNames{feature}] ;
    end
end 
% add label to channels features col names
featuresNames_channel=[featuresNames_channel "Label"];

% fetch data dimentions
[observations, features] = size(JawClench_tabel); 




% create filters for the classes
nonJawClench = JawClench_tabel(:,features) == 0;
JawClench = JawClench_tabel(:,features) == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);



% fetch data dimentions for nonClench_tabel
[nJ_observations, nJ_features] = size(nonClench_tabel);

% loop over class observations 
for j=1:nJ_observations 
   % random assigned number for each observations to new column
   nonClench_tabel(j,features+1)=rand; 
end


% sort based on the random assigned number column
rand_table=sortrows(nonClench_tabel,features+1);
% take the first n observarions to make Clench_tabel observarions
nonClench_tabel_less = rand_table(1:height(Clench_tabel),1:features);


% combine the tables
newJawClench_tabel = [nonClench_tabel_less;Clench_tabel];


% normalise data 
for col=1:features-1
    data = newJawClench_tabel(:,col);
    max_value = max(data);
    min_value = min(data);
    data = (data-min_value)/(max_value-min_value);
    mean_value = mean(data);
    std_value = std(data);
    data = (data-mean_value)/(std_value);
    newJawClench_tabel(:,col) = data;
end

% Set columns names to dataset
newJawClench_tabel = array2table(newJawClench_tabel,'VariableNames',featuresNames_channel);
% save dataset to file
writetable(newJawClench_tabel,"balanced_Data_JawClench_features.csv");









