clear;
clc;
close all;


% set source files folder name   
dir_name = 'Data_RandomClench_features';
% set file types
match = '*.csv';
% read data files paths
csv_files = dir(fullfile(dir_name, match));
datasets_filenames = struct2cell(csv_files);
datasets_filenames = append(datasets_filenames(2,:), '/', datasets_filenames(1,:));


number_feature_to_extracted  = 4; % where 3 i4 the number of feature you plan to exratct
number_features = 7 * number_feature_to_extracted; % where 7*4 is the number of feature you plan to exratct form channels

% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak_Value", "Standard_Dev", "SND_Ratio"];
 featuresNames_channel = []; 

 % create the feature names 
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       featuresNames_channel=[featuresNames_channel channels{channel}+"_"+featuresNames{feature}] ;
    end
end 
featuresNames_channel=[featuresNames_channel "Label"];

% initilaze  output file
outfile = [] ;
% loop through file to combine the dataset
for dataset = 1:width(datasets_filenames)
%     read data file
    ftable = readmatrix(char(datasets_filenames(dataset)));
    % mergae data fire to the output file
    outfile = [outfile;ftable];
    

end
% create table and add feature name
table = array2table(outfile,'VariableNames',featuresNames_channel);
% save file
writetable(table,"Data_JawClench_features.csv");












% writetable(fTable,outfile,'Sheet',datasets_filenames(dataset))