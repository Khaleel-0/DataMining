clear;
clc;
close all;
% read dataset
JawClench_tabel = readtable("Data_JawClench_features.csv");



% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];
 cols = []; 

% create the feature names 
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+" "+featuresNames{feature}] ;
    end
end


% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% set classes tables list
tables = {nonClench_tabel; Clench_tabel};
classes  = {"nonJawClench","JawClench"};



computed_cov = {};
computed_values = {};
%loop over the countries' datasets to calculate its features' basic stat
for i = 1:numel(tables)
    % fetch the country dataset to be plotted 
    table = tables{i};
    disp(classes(i));
    disp("----------");
    %loop over the country dataset features to calculate basic stat
    for col = 1:width(table)-1
        values = {};
        % calculate feature's max, min, mean, variance, median and std
        max_value = max(table{:,col});
        min_value = min(table{:,col});
        mean_value = mean(table{:,col});
        variance_value = var(table{:,col});
        median_value = median(table{:,col});
        std_value = std(table{:,col});
        % add the feature's basic stat values to a array
        values{1} = max_value;
        values{2} = min_value;
        values{3} = mean_value;
        values{4} = variance_value;
        values{5} = median_value;
        values{6} = std_value;
        % disply the feature's basic stat values 
        disp(" - "+cols(col)+" Min: "+ round(min_value,3) +", Max: "+round(max_value,3) +", Mean: "+ round(mean_value,3) +", Median: "+round(median_value,3)+", and Variance: "+round(variance_value,3) );
        % apped the feature's basic stat vales to a the computed_values 2d array col: countries and row: features
        computed_values{i,col} = values;
    end
    % compute the country's cov matrix
    cov_mat=cov(table2array(table(:,1:width(table)-1)));
    % append the country's cov matrix to computed_cov array
    computed_cov{i} = cov_mat;   
end


% normlized and mean center that datasets
for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
     mean_value = mean(data);
     std_value = std(data);
     data = (data-mean_value)/std_value;
     

     JawClench_tabel{:,col} = data;
end


% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% set classes tables list
tables = {nonClench_tabel; Clench_tabel};
classes  = {"nonJawClench","JawClench"};

%plot histograms
for col= 1:width(JawClench_tabel)-1

    fig = figure;
    hold on
    for i=1:length(tables)

    table = tables{i};
    h = histogram(table{:,col});
    title("Histogram of "+cols(col) ); 
    ylabel ("Frequency");
    xlabel (cols(col));
    

    
    end
    legend(classes);
    hold off
    saveas(fig,"Histograms_normilized/"+cols(col)+"_histogram.png");
end




% close all;









