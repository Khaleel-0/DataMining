clear;
clc;
close all;

%Author: Pragati Dode

JawClench_tabel1 =readtable("Data_JawClench_features.csv");



nonJawClench = JawClench_tabel1.Label == 0;
JawClench = JawClench_tabel1.Label == 1; 


nonJawClench_tabel = JawClench_tabel1(nonJawClench,:);
JawClench_tabel = JawClench_tabel1(JawClench,:);

tables = {nonJawClench_tabel; JawClench_tabel};
classes  = ["JawClench", "nonJawClench"];

channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];

featuresNames = ["Mean", "Peak_Value", "Standard_Dev", "SNR"];
 cols = []; 

for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+"_"+featuresNames{feature}] ;
    end
end



computed_cov = {};
computed_values = {};
%loop over the countries' datasets to calculate its features' basic stat
for i = 1:numel(tables)
    % fetch the country dataset to be plotted 
    table = tables{i};
    disp(classes(i));
    disp("----------");
    %loop over the country dataset features to calculate basic stat
    for col = 1:width(table)-1
        values = {};
        % calculate feature's max, min, mean, variance, median and std
        max_value = max(table{:,col});
        min_value = min(table{:,col});
        mean_value = mean(table{:,col});
        variance_value = var(table{:,col});
        median_value = median(table{:,col});
        std_value = std(table{:,col});
        % add the feature's basic stat values to a array
        values{1} = max_value;
        values{2} = min_value;
        values{3} = mean_value;
        values{4} = variance_value;
        values{5} = median_value;
        values{6} = std_value;
        % disply the feature's basic stat values 
        disp(cols(col)+": max: "+max_value +" min: "+ min_value +" mean: "+ mean_value +" variance: "+variance_value +" median: "+median_value);
        % apped the feature's basic stat vales to a the computed_values 2d array col: countries and row: features
        computed_values{i,col} = values;
    end
    % compute the country's cov matrix
    cov_mat=cov(table2array(table));
    
    % append the country's cov matrix to computed_cov array
    computed_cov{i} = cov_mat;   
end



for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
     mean_value = mean(data);
     std_value = std(data);
     data = (data-mean_value)/std_value;
     

     JawClench_tabel{:,col} = data;
end


% Conevrts JawClench_tabel1 to JawClenchMatrix
JawClenchMatrix = table2array(JawClench_tabel);
% fetch classes indices from JawClenchMatrix
rows_JawClench = JawClenchMatrix (:,29)==1;
rows_NonJawClench =  JawClenchMatrix (:,29)==0;


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %  

% Basic PCA process script 

% this just transforms and plots data, it is up to you 

% to provide the appropriate interpretation, which is the 

% most valuable part of PCA 

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %  

% Conevrts JawClench_tabel1 to JawClenchMatrix
JawClenchMatrix1 = table2array(JawClench_tabel1);

[nrows, ncols] = size(JawClenchMatrix1); 

Jaw_data = zeros([nrows,ncols]); 

ss_i = zeros([1,ncols]);   % you could use this for the scree plot 

ss_cu = zeros([1,ncols]);  % you could use this for the cumulative scree plot 

 

means = mean(JawClenchMatrix1);    

vars = var(JawClenchMatrix1); 

stdevs = std(JawClenchMatrix1); 






% Scale data 

% This is necessary so that all data has the same order, e.g.,  

% should not compare values in the thousands vs. values between 0 and 1 

%

for i=1:ncols 

    col_max = max(JawClenchMatrix1(:,i));
    col_min = min(JawClenchMatrix1(:,i));

    for j=1:nrows
        if i == 1
            Jaw_data(j,i) = JawClenchMatrix1(j,i); 
        else

        Jaw_data(j,i) = (JawClenchMatrix1(j,i) - col_min )/(col_max-col_min);
        end 

    end 

end 


% Mean center data 
% 
% This is necessary so that everything is mean centered at 0 
% 
% facilitates statistical and hypothesis analysis 


for i=1:ncols 

    for j=1:nrows
        if i == 1
            Jaw_data(j,i) = JawClenchMatrix1(j,i); 
        else

        Jaw_data(j,i) = (JawClenchMatrix1(j,i) -  means(:,i))/stdevs(:,i);
        end 

    end 

end 

abs(mean(Jaw_data)) 



var(Jaw_data) 


% 

% covid_data is the original dataset 

% Ur will be the transformed dataset  

% S is covariance matrix (not normalized) 

% 



[U, S ,V] = svd(Jaw_data(:,1:ncols-1),0); 

Ur = U*S;                

 

% Number of features to use 

f_to_use = ncols-1;      

feature_vector = 2:f_to_use; 

 

r = Ur;  % make a copy of Ur to preserve it,  we will randomize r  

 

        

% 

% Obtain the necessary information for Scree Plots 

% Obtain S^2 (and can also use to normalize S)   

% 

S2 = S^2; 

weights2 = zeros(ncols-1,1); 

sumS2 = sum(sum(S2)); 

weightsum2 = 0; 

 

for i=1:(ncols-1) 

    weights2(i) = S2(i,i)/sumS2; 

    weightsum2 = weightsum2 + weights2(i); 

    weight_c2(i) = weightsum2; 

end 


figure; 


hold on

plot(weights2,'x:b'); 
plot(weight_c2,'x:r'); 

grid; 

title('Scree Plot and Scree Plot Cumulative'); 
legend({"Scree Plot","Scree Plot Cumulative"})

hold off

nfeatures = ncols-1;

for i=1:nfeatures

    for j=1:nfeatures 

        Vsquare(i,j) = V(i,j)^2; 

        if V(i,j)<0 

            Vsquare(i,j) = Vsquare(i,j)*-1; 

        else  

            Vsquare(i,j) = Vsquare(i,j)*1; 

        end 

    end 

end 

for v = 1:width(Vsquare)


    figure; 
    
    bar(Vsquare(:,v),0.5); 
    
    grid; 
    
    ymin = min(Vsquare(:,v)) + (min(Vsquare(:,v))/10); 
    
    ymax = max(Vsquare(:,v)) + (max(Vsquare(:,v))/10); 
    
    axis([0 nfeatures ymin ymax]); 
    
    xlabel('Feature index'); 
    
    ylabel('Importance of feature'); 
    
    [chart_title, ERRMSG] = sprintf('Loading Vector %d',v); 
    
    title(chart_title);

end
