clear;
clc;
close all;

window_size = 300;

dir_name = 'Data_RandomClench_labeled';

dest_dir_name = 'Data_RandomClench_features';

match = '*.csv';

csv_files = dir(fullfile(dir_name, match));

sFE = signalTimeFeatureExtractor(FrameSize=300,Mean=true,PeakValue=true,StandardDeviation=true,SNR=true);


datasets_filenames = struct2cell(csv_files);
datasets_filenames = append(datasets_filenames(2,:), '/', datasets_filenames(1,:));
number_feature_to_extracted  = 4; % where 3 i4 the number of feature you plan to exratct
number_features = 7 * number_feature_to_extracted; % where 7*4 is the number of feature you plan to exratct form channels

for dataset = 1:length(datasets_filenames)
    dataset_m = readmatrix(char(datasets_filenames(dataset)));
    offset = 0;
    number_observations = height(dataset_m)/window_size;
    featuresExtracted = extract(sFE,dataset_m);
    final_observation = zeros([number_observations number_features+1]);
    for observation = 1:number_observations
        channel_features_index = 1;
        observation_window = dataset_m(offset+1:offset+window_size,:);
        for channel =1:width(observation_window)
            if channel == width(observation_window) % this the label column
                final_observation(observation,width(final_observation)) = max(observation_window(:,channel));% take the max of the label
            else % this the channels columns
                % extratct channels features from observation_window and 
                % column channle_features_index+1 for the 1st feature
                % column channle_features_index+2 for the 2cd feature
                % column channle_features_index+3 for the 3rd feature

                final_observation(observation,channel_features_index) = featuresExtracted(observation,1,channel);
                final_observation(observation,channel_features_index+1) = featuresExtracted(observation,2,channel);
                final_observation(observation,channel_features_index+2) = featuresExtracted(observation,3,channel);
                final_observation(observation,channel_features_index+3) = featuresExtracted(observation,4,channel);

                %final_observation(observation,channle_features_index) =
                %final_observation(observation,channle_features_index+1) =
                %final_observation(observation,channle_features_index+2) =
                
                channel_features_index = channel_features_index + number_feature_to_extracted;

            end    
        end
        offset = offset+window_size;
    end
    
    writematrix(final_observation, dest_dir_name+"/dataset_"+dataset+"_features.csv");
end
