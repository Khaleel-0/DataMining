clear;
clc;
close all;
% set window size
window_size = 300;
% set source files folder name   
dir_name = 'Data_RandomClench_dest';

match = '*.csv';
% read data files paths
csv_files = dir(fullfile(dir_name, match));
datasets_filenames = struct2cell(csv_files);
datasets_filenames = append(datasets_filenames(2,:), '/', datasets_filenames(1,:));

% loop data files to label them
for dataset = 1:length(datasets_filenames)
    % read data file
    dataset_m= readmatrix(char(datasets_filenames(dataset)));
    
    disp(dataset);
    col = 0;

    channels_labels = zeros(height(dataset_m),7);
    labeled_dataset = zeros(height(dataset_m),8);
    % loop through channels 
    for channel = 1:width(dataset_m)/2
        % fetch channel data
        col = col+ 1;
        labeled_dataset(:,channel)= dataset_m(:,col);
        % calculate channel auc mean
        col = col+ 1;
        channel_auc = dataset_m(:,col);
        [channel_auc_i, channel_auc_x ,channel_auc_v]  = find(channel_auc);
        mean_auc = mean(channel_auc_v);
        offset = 0;
        % loop through channel widow and compare them to channel auc mean to
        % label window 
        for window = 1:length(channel_auc_i)
            % set window  offset 
            offset = offset+1;
%           % fetch windows data 
            window_data = channel_auc(offset:channel_auc_i(window));
           %compare them to channel auc mean to label window
            if channel_auc_v(window)> mean_auc
                label= 1;
            else
                label= 0;
            end
            % set window label
            channels_labels(offset:channel_auc_i(window),channel) =  label;
%             update offset 
            offset = channel_auc_i(window);
        end
   
    end
    % take channles majority voting to set finale label
    labeled_dataset(:,8) = take_majority_vote(sum(channels_labels,2));
    
    % remove end of data the does not form window 
    labeled_dataset = labeled_dataset(1:channel_auc_i(length(channel_auc_i)),:);

    % save label data
    writematrix(labeled_dataset, "Data_RandomClench_labeled/dataset_"+dataset+"_labeled.csv");
end

% take channles majority voting to set finale label
function dataset_label = take_majority_vote(votes)
    dataset_label = zeros(length(votes),1);
    for row =1:length(votes) 
        if votes(row) > 3
          dataset_label(row) = 1; 
        end
    end
end


