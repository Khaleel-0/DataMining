clear;
clc;
close all;

%% NOTE:
% Due to matlab being a good programming language this script assumes the
% current folder (which is shown on the left of the ide) has both the data
% files and the program files.

% raw_unordered_eeg = parse_eeg('Data_RandomClench', '*_raw.csv', true);

do_highpass = true;

raw_unordered_eeg = parse_eeg('Data_RandomClench', '*_raw.csv', do_highpass);

% filtered_ordered_eeg = parse_eeg('Data_Clench_RAW', '*_filtered.csv');

%% Gabor transform
% Create a sliding window, do fft(fast fourier transform) on every
% sliding window, record maybe the mode or slice the fft graph into pieces
% and then recording the pieces

window_size = 300;
window_overlap = 0;
display_internal_fft = false;

% apply the 
for dataset = 1:width(raw_unordered_eeg)
    graph = graph_gabor(raw_unordered_eeg(dataset), window_size, window_overlap, display_internal_fft);
    % Remove 1st second 
    graph_2 = graph(window_size+1:height(graph),:);
    
    %save matrix as csv
    writematrix(graph_2, "Data_RandomClench_dest/dataset_"+dataset+".csv");
end


