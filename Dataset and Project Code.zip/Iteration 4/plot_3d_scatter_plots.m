clear;
clc;
close all;
% read dataset
JawClench_tabel = readtable("Data_JawClench_features.csv");

%Authors: Noura Alroomi, Melody Behdarvandian, Pragati Dode, Khaleel Rehman

% denfine channels names
channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];
% denfine features
featuresNames = ["Mean", "Peak Value", "Standard Dev", "SNR"];
 cols = []; 

% create the feature names 
for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+" "+featuresNames{feature}] ;
    end
end


% create filters for the classes
nonJawClench = JawClench_tabel.Label == 0;
JawClench = JawClench_tabel.Label == 1; 

% fetch classes data based on filters
nonClench_tabel = JawClench_tabel(nonJawClench,:);
Clench_tabel = JawClench_tabel(JawClench,:);

% set classes tables list
tables = {nonClench_tabel; Clench_tabel};
classes  = {"nonJawClench","JawClench"};


% normlized and mean center that datasets
for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
%      mean_value = mean(data);
%      std_value = std(data);
%      data = (data-mean_value)/std_value;
     

     JawClench_tabel{:,col} = data;
end

% create plots combinations
scatter_plots_3d = nchoosek(1:7,3);

% loop over features to plot channels 3d plots combinations  
for feature = 1:length(featuresNames)
    % fetch channels features indicies
    cols_indcies = [];
    for col =1 :width(JawClench_tabel)-1
        if feature == length(featuresNames)
            if mod(col,4) == 0
                cols_indcies = [cols_indcies col];
            end
        else
            if mod(col,4) == feature
                cols_indcies = [cols_indcies col];
            end
        end
    end
    
    % create filters for the classes
    nonJawClench = JawClench_tabel.Label == 0;
    JawClench = JawClench_tabel.Label == 1; 
    % fetch classes data based on filters
    feature_nonClench_tabel = table2array(JawClench_tabel(nonJawClench,cols_indcies));
    feature_Clench_tabel = table2array(JawClench_tabel(JawClench,cols_indcies));
    
    
    % plot 3D Scatter plot based combinations
    for comb= 1:height(scatter_plots_3d)
        % fetch channels combinations
        sp = scatter_plots_3d(comb,:);
        fig = figure();
        % plot nonClench  data
        scatter3(feature_nonClench_tabel(:,sp(1)),feature_nonClench_tabel(:,sp(2)),feature_nonClench_tabel(:,sp(3)),"blue")
        hold on
        % plot clench  data
        scatter3(feature_Clench_tabel(:,sp(1)),feature_Clench_tabel(:,sp(2)),feature_Clench_tabel(:,sp(3)),"red")
        % add title
        title(channels(sp(1))+ ", "+ channels(sp(2))+" and "+channels(sp(3)) +" "+featuresNames(feature) +"s Scatter Plot")
        % add x y z access label
        xlabel(channels(sp(1)))
        ylabel(channels(sp(2)))
        zlabel(channels(sp(3)))
        % add legend
        legend(classes);
        hold off 
        % save fig
%         saveas(fig,featuresNames(feature)+"_3d/"+channels(sp(1))+ ", "+ channels(sp(2))+" and "+channels(sp(3)) +" "+featuresNames(feature) +"s Scatter Plot.png");
    end
    close all;
end




