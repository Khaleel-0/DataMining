clear;
clc;
close all;

JawClench_tabel1 =readtable("Data_JawClench_features.csv");



nonJawClench = JawClench_tabel1.Label == 0;
JawClench = JawClench_tabel1.Label == 1; 


nonJawClench_tabel = JawClench_tabel1(nonJawClench,:);
JawClench_tabel = JawClench_tabel1(JawClench,:);

tables = {nonJawClench_tabel; JawClench_tabel};
classes  = ["JawClench", "nonJawClench"];

channels = ["LE", "F4", "C4", "P4", "P3", "C3", "F3"];

featuresNames = ["Mean", "Peak_Value", "Standard_Dev", "SNR"];
 cols = []; 

for channel = 1 :length(channels)
    for feature =1:length(featuresNames)
       cols=[cols channels{channel}+"_"+featuresNames{feature}] ;
    end
end



computed_cov = {};
computed_values = {};
%loop over the countries' datasets to calculate its features' basic stat
for i = 1:numel(tables)
    % fetch the country dataset to be plotted 
    table = tables{i};
    disp(classes(i));
    disp("----------");
    %loop over the country dataset features to calculate basic stat
    for col = 1:width(table)-1
        values = {};
        % calculate feature's max, min, mean, variance, median and std
        max_value = max(table{:,col});
        min_value = min(table{:,col});
        mean_value = mean(table{:,col});
        variance_value = var(table{:,col});
        median_value = median(table{:,col});
        std_value = std(table{:,col});
        % add the feature's basic stat values to a array
        values{1} = max_value;
        values{2} = min_value;
        values{3} = mean_value;
        values{4} = variance_value;
        values{5} = median_value;
        values{6} = std_value;
        % disply the feature's basic stat values 
        disp(cols(col)+": max: "+max_value +" min: "+ min_value +" mean: "+ mean_value +" variance: "+variance_value +" median: "+median_value);
        % apped the feature's basic stat vales to a the computed_values 2d array col: countries and row: features
        computed_values{i,col} = values;
    end
    % compute the country's cov matrix
    cov_mat=cov(table2array(table));
    
    % append the country's cov matrix to computed_cov array
    computed_cov{i} = cov_mat;   
end



for col =1 :width(JawClench_tabel)-1

     data = JawClench_tabel{:,col};
     max_value = max(data);
     min_value = min(data);
     data = (data-min_value)/(max_value-min_value);
     mean_value = mean(data);
     std_value = std(data);
     data = (data-mean_value)/std_value;
     

     JawClench_tabel{:,col} = data;
end

% Conevrts JawClench_tabel1 to JawClenchMatrix
JawClenchMatrix = table2array(JawClench_tabel1);
% fetch classes indices from JawClenchMatrix
rows_JawClench = JawClenchMatrix (:,29)==1;
rows_NonJawClench =  JawClenchMatrix (:,29)==0;

%
% SCATTER PLOT FOR CHANNELS-1 FEATURES
%

cols = ["LE Mean","LE Peak Value", "LE Std Dev", "LE SNR" ];
 
% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[1:4]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[1:4]);

subpl = 1;
figure
for row= 1:length(cols)
%loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 1 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end


%
% SCATTER PLOT FOR CHANNELS-2 FEATURES
%

cols = ["F4 Mean","F4 Peak Value", "F4 Std Dev", "F4 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[5:8]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[5:8]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 2 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end

%
%SCATTER PLOT FOR CHANNELS-3 FEATURES
%

cols = ["C4 Mean","C4 Peak Value", "C4 Std Dev", "C4 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[9:12]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[9:12]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 3 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end

%
%SCATTER PLOT FOR CHANNELS-4 FEATURES
%

cols = ["P4 Mean","P4 Peak Value", "P4 Std Dev", "P4 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[13:16]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[13:16]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 4 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end

%
%SCATTER PLOT FOR CHANNELS-5 FEATURES
%

cols = ["P3 Mean","P3 Peak Value", "P3 Std Dev", "P3 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[17:20]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[17:20]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 5 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end


%
%SCATTER PLOT FOR CHANNELS-6 FEATURES
%

cols = ["C3 Mean","C3 Peak Value", "C3 Std Dev", "C3 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[21:24]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[21:24]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 6 FEATURES','Color','blue') 
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
       xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end

%
%SCATTER PLOT FOR CHANNELS-7 FEATURES
%

cols = ["F3 Mean","F3 Peak Value", "F3 Std Dev", "F3 SNR" ];

% fetch classes from JawClenchMatrix
mat_JawClench = JawClenchMatrix(rows_JawClench,[25:28]);
mat_NonJawClench = JawClenchMatrix(rows_NonJawClench,[25:28]);

subpl = 1;
figure
for row= 1:length(cols)
    %loop over Matrix of Scatter Plots columns
    for col =1:length(cols)
    sgtitle('CHANNEL- 7 FEATURES','Color','blue') 
     
    % set Scatter Plot location in Matrix 
    subplot(length(cols), length(cols),subpl)
    hold on
    % draw scatter plot 
    scatter(mat_JawClench(:,col),mat_JawClench(:,row),"red")
    scatter(mat_NonJawClench(:,col),mat_NonJawClench(:,row),'blue')
    % add y axis lable in the first colunm of the matrix
    if col == 1
        ylabel (cols(row));
    end
    % add x axis lable in the last row of the matrix
    if row == length(cols) 
        xlabel (cols(col));
    end
    hold off
    % rest plot loaction in the matrix 
    subpl = subpl + 1;
    end 
end


